from keras_vggface.vggface import VGGFace
from keras_vggface.version import __version__